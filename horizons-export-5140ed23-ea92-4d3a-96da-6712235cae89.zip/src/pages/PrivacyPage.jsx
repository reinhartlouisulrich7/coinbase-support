import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const PrivacyPage = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | CryptoSupport Pro</title>
        <meta name="description" content="Read the Privacy Policy for CryptoSupport Pro to understand how we handle your data." />
      </Helmet>
      <div className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white">Privacy Policy</h1>
            <p className="mt-2 text-slate-400">Last Updated: {new Date().toLocaleDateString()}</p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="mt-12 prose prose-invert prose-lg max-w-none text-slate-300 prose-headings:text-white prose-a:text-violet-400 hover:prose-a:text-violet-300"
          >
            <h2>1. Information We Collect</h2>
            <p>
              We collect information you provide directly to us when you use our services. This may include your name, email address, phone number, and a description of the support issue you are experiencing. We do not collect or store sensitive information like private keys, seed phrases, or passwords.
            </p>
            
            <h2>2. How We Use Your Information</h2>
            <p>
              We use the information we collect to:
            </p>
            <ul>
              <li>Provide, maintain, and improve our services.</li>
              <li>Communicate with you, including responding to your comments, questions, and requests.</li>
              <li>Send you technical notices, updates, and support messages.</li>
              <li>Monitor and analyze trends, usage, and activities in connection with our services.</li>
            </ul>

            <h2>3. Information Sharing</h2>
            <p>
              We do not share your personal information with third parties except as described in this Privacy Policy or with your consent. We may share information with vendors, consultants, and other service providers who need access to such information to carry out work on our behalf.
            </p>

            <h2>4. Data Security</h2>
            <p>
              We take reasonable measures to help protect information about you from loss, theft, misuse, and unauthorized access, disclosure, alteration, and destruction. However, no security system is impenetrable, and we cannot guarantee the security of our systems 100%.
            </p>

            <h2>5. Your Choices</h2>
            <p>
              You may update, correct, or delete information about you at any time by emailing us. Please note that we may retain certain information as required by law or for legitimate business purposes.
            </p>
            
            <h2>6. Changes to This Policy</h2>
            <p>
              We may change this Privacy Policy from time to time. If we make changes, we will notify you by revising the date at the top of the policy and, in some cases, we may provide you with additional notice.
            </p>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default PrivacyPage;