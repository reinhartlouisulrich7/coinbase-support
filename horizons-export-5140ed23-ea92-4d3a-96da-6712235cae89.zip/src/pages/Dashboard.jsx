import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { cryptoData } from '@/data/crypto';
import { formatPrice, formatMarketCap } from '@/lib/utils';

import Header from '@/components/Header';
import FeaturedCrypto from '@/components/FeaturedCrypto';
import MarketOverview from '@/components/MarketOverview';
import Portfolio from '@/components/Portfolio';
import Watchlist from '@/components/Watchlist';
import MarketStats from '@/components/MarketStats';

function Dashboard() {
  const [selectedCrypto, setSelectedCrypto] = useState('bitcoin');
  const [portfolio, setPortfolio] = useState([]);
  const [watchlist, setWatchlist] = useState([]);

  const addToWatchlist = (crypto) => {
    if (!watchlist.find(item => item.id === crypto.id)) {
      setWatchlist([...watchlist, crypto]);
      toast({
        title: "Added to Watchlist",
        description: `${crypto.name} has been added to your watchlist!`,
        className: 'bg-gray-800 text-white border-yellow-500',
      });
    } else {
      toast({
        title: "Already in Watchlist",
        description: `${crypto.name} is already in your watchlist.`,
        variant: 'destructive',
        className: 'bg-gray-800 text-white border-red-500',
      });
    }
  };

  const addToPortfolio = (crypto) => {
    const existingItem = portfolio.find(item => item.id === crypto.id);
    if (existingItem) {
      setPortfolio(portfolio.map(item => 
        item.id === crypto.id 
          ? { ...item, amount: item.amount + 0.1 }
          : item
      ));
    } else {
      setPortfolio([...portfolio, { ...crypto, amount: 0.1 }]);
    }
    toast({
      title: "Added to Portfolio",
      description: `0.1 ${crypto.symbol} added to your portfolio!`,
      className: 'bg-gray-800 text-white border-green-500',
    });
  };

  const removeFromPortfolio = (cryptoId) => {
    const existingItem = portfolio.find(item => item.id === cryptoId);
    if (existingItem && existingItem.amount > 0.1) {
      setPortfolio(portfolio.map(item => 
        item.id === cryptoId 
          ? { ...item, amount: item.amount - 0.1 }
          : item
      ));
    } else {
      setPortfolio(portfolio.filter(item => item.id !== cryptoId));
    }
    toast({
      title: "Removed from Portfolio",
      description: "Position updated successfully!",
      className: 'bg-gray-800 text-white border-red-500',
    });
  };

  const selectedCryptoData = cryptoData.find(crypto => crypto.id === selectedCrypto);
  const totalPortfolioValue = portfolio.reduce((total, item) => total + (item.price * item.amount), 0);

  return (
    <div className="dark min-h-screen bg-gray-900 text-gray-100">
      <Header totalPortfolioValue={totalPortfolioValue} formatPrice={formatPrice} />

      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-9 space-y-6">
            <FeaturedCrypto
              crypto={selectedCryptoData}
              formatPrice={formatPrice}
              formatMarketCap={formatMarketCap}
              addToPortfolio={addToPortfolio}
              removeFromPortfolio={removeFromPortfolio}
              addToWatchlist={addToWatchlist}
            />
            <MarketOverview
              cryptos={cryptoData}
              setSelectedCrypto={setSelectedCrypto}
              formatPrice={formatPrice}
              formatMarketCap={formatMarketCap}
            />
          </div>
          <div className="lg:col-span-3 space-y-6">
            <Portfolio
              portfolio={portfolio}
              totalPortfolioValue={totalPortfolioValue}
              formatPrice={formatPrice}
            />
            <Watchlist
              watchlist={watchlist}
              formatPrice={formatPrice}
            />
            <MarketStats />
          </div>
        </div>
      </main>
    </div>
  );
}

export default Dashboard;