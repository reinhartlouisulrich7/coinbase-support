import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ShieldCheck, LifeBuoy, MessageSquare, Lock, Search, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 100,
    },
  },
};

const services = [
  { icon: ShieldCheck, title: 'Wallet Recovery', description: 'Expert assistance with recovering access to lost or inaccessible crypto wallets through secure, guided methods.' },
  { icon: LifeBuoy, title: 'Transaction Issues', description: 'Troubleshooting for pending, stuck, failed, or unconfirmed transactions on various blockchain networks.' },
  { icon: MessageSquare, title: 'Exchange Account Support', description: 'Help with account access, trading issues, API configuration, and deposit/withdrawal problems on major exchanges.' },
  { icon: Lock, title: 'Security Consultation', description: 'Personal security audits to protect your digital assets from phishing, scams, and other online threats.' },
  { icon: Search, title: 'Asset Tracing', description: 'Assistance in tracing movement of funds on the blockchain for analysis and reporting purposes.' },
  { icon: HelpCircle, title: 'General Guidance', description: 'Personalized sessions to help you understand and safely navigate the complexities of the crypto ecosystem.' },
];

const ServicesPage = () => {
  return (
    <>
      <Helmet>
        <title>Our Services | CryptoSupport Pro</title>
        <meta name="description" content="Explore the full range of third-party support services offered by CryptoSupport Pro, from wallet recovery to security consultations." />
      </Helmet>
      <div className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={containerVariants}
            className="text-center"
          >
            <motion.h1 variants={itemVariants} className="text-4xl sm:text-5xl font-extrabold text-white">Our Support Services</motion.h1>
            <motion.p variants={itemVariants} className="mt-4 max-w-2xl mx-auto text-lg text-slate-300">
              We offer a comprehensive suite of specialized services to resolve your crypto-related problems efficiently and securely.
            </motion.p>
          </motion.div>

          <motion.div 
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {services.map((service, index) => (
              <motion.div key={index} variants={itemVariants} className="bg-slate-800 p-8 rounded-lg border border-slate-700 flex flex-col hover:border-violet-500 hover:scale-105 transition-all duration-300">
                <div className="flex-shrink-0">
                  <div className="inline-block p-4 bg-violet-600/20 text-violet-400 rounded-full mb-4">
                    <service.icon className="w-8 h-8" />
                  </div>
                </div>
                <div className="flex-grow">
                  <h2 className="text-2xl font-bold text-white mb-2">{service.title}</h2>
                  <p className="text-slate-400">{service.description}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-20 text-center bg-slate-800/50 p-10 rounded-lg border border-slate-700"
          >
            <h2 className="text-3xl font-bold text-white">Ready to Get Started?</h2>
            <p className="mt-4 text-slate-300 max-w-xl mx-auto">Don't let technical issues hold you back. Contact our expert team today for a free, no-obligation consultation.</p>
            <Button asChild size="lg" className="mt-6 bg-violet-600 hover:bg-violet-700 text-white font-bold">
              <Link to="/contact">Contact Us Now</Link>
            </Button>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ServicesPage;