import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Phone, Mail, Clock, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';

const ContactPage = () => {
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: 'Form Submitted!',
      description: 'Thank you for reaching out. We will get back to you shortly.',
      className: 'bg-green-500 text-white border-green-600',
    });
    e.target.reset();
  };

  return (
    <>
      <Helmet>
        <title>Contact Us | CryptoSupport Pro</title>
        <meta name="description" content="Contact CryptoSupport Pro for expert third-party assistance with your cryptocurrency and exchange issues. Reach out for a free consultation." />
      </Helmet>
      <div className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white">Get in Touch</h1>
            <p className="mt-4 max-w-2xl mx-auto text-lg text-slate-300">
              We're here to help. Reach out to us via phone, email, or the contact form below.
            </p>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <motion.div 
              initial={{ opacity: 0, x: -50 }} 
              whileInView={{ opacity: 1, x: 0 }} 
              viewport={{ once: true }} 
              transition={{ duration: 0.7 }}
              className="space-y-8"
            >
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 flex items-center space-x-4">
                <Phone className="w-8 h-8 text-violet-400 flex-shrink-0" />
                <div>
                  <h2 className="text-xl font-bold text-white">Call Us</h2>
                  <a href="tel:+1-800-555-0199" className="text-slate-300 hover:text-violet-300 transition-colors">+1 (800) 555-0199</a>
                </div>
              </div>
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 flex items-center space-x-4">
                <Mail className="w-8 h-8 text-violet-400 flex-shrink-0" />
                <div>
                  <h2 className="text-xl font-bold text-white">Email Us</h2>
                  <a href="mailto:support@cryptosupportpro.example.com" className="text-slate-300 hover:text-violet-300 transition-colors">support@cryptosupportpro.example.com</a>
                </div>
              </div>
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 flex items-center space-x-4">
                <Clock className="w-8 h-8 text-violet-400 flex-shrink-0" />
                <div>
                  <h2 className="text-xl font-bold text-white">Business Hours</h2>
                  <p className="text-slate-300">Monday - Friday: 9:00 AM - 6:00 PM (EST)</p>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 50 }} 
              whileInView={{ opacity: 1, x: 0 }} 
              viewport={{ once: true }} 
              transition={{ duration: 0.7 }}
            >
              <form onSubmit={handleSubmit} className="bg-slate-800 p-8 rounded-lg border border-slate-700 space-y-6">
                <h2 className="text-2xl font-bold text-white">Request a Callback</h2>
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-slate-300">Full Name</Label>
                  <Input id="name" type="text" placeholder="John Doe" required className="bg-slate-900 border-slate-600 text-white focus:ring-violet-500" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-slate-300">Email Address</Label>
                  <Input id="email" type="email" placeholder="you@example.com" required className="bg-slate-900 border-slate-600 text-white focus:ring-violet-500" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="issue" className="text-slate-300">Describe Your Issue</Label>
                  <textarea id="issue" placeholder="Please provide a brief description of the problem..." required className="w-full min-h-[100px] bg-slate-900 border border-slate-600 rounded-md p-2 text-white focus:ring-violet-500 focus:outline-none"></textarea>
                </div>
                <Button type="submit" className="w-full bg-violet-600 hover:bg-violet-700 text-white font-semibold text-lg py-3">Submit Request</Button>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ContactPage;