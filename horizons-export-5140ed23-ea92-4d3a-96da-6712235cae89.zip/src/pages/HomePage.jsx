import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Phone, MessageSquare, ShieldCheck, LifeBuoy } from 'lucide-react';
import { Button } from '@/components/ui/button';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 100,
    },
  },
};

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>Expert Crypto & Exchange Support | Secure & Reliable Help</title>
        <meta name="description" content="Get expert, third-party support for your cryptocurrency and exchange issues. Fast, reliable solutions for wallet recovery, transaction problems, and more. Contact us for a free consultation." />
        <meta name="keywords" content="crypto support, third-party crypto help, exchange support, wallet recovery, cryptocurrency help" />
      </Helmet>
      <div className="bg-slate-900 text-slate-50 overflow-x-hidden">
        <HeroSection />
        <SupportedPlatforms />
        <HowItWorksSection />
        <ServicesPreview />
        <DisclaimerSection />
      </div>
    </>
  );
};

const HeroSection = () => (
  <section className="relative py-20 sm:py-28 text-center overflow-hidden">
    <div className="glow-effect"></div>
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
      <motion.div variants={containerVariants} initial="hidden" animate="visible">
        <motion.h1 variants={itemVariants} className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight">
          Expert Support for Your Crypto & Exchange Needs
        </motion.h1>
        <motion.p variants={itemVariants} className="mt-6 max-w-2xl mx-auto text-lg text-slate-300">
          Facing issues with your wallet, transactions, or exchange account? Our independent team of specialists is here to provide fast, reliable third-party support.
        </motion.p>
        <motion.div variants={itemVariants} className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-4">
          <Button asChild size="lg" className="w-full sm:w-auto bg-violet-600 hover:bg-violet-700 text-white font-bold shadow-lg shadow-violet-500/20">
            <a href="tel:+1-800-555-0199">
              <Phone className="mr-2 h-5 w-5" /> Call for Immediate Help
            </a>
          </Button>
          <Button asChild size="lg" variant="outline" className="w-full sm:w-auto border-violet-500 text-violet-400 hover:bg-violet-500/10 hover:text-violet-300 font-bold">
            <Link to="/contact">
              <MessageSquare className="mr-2 h-5 w-5" /> Request a Callback
            </Link>
          </Button>
        </motion.div>
      </motion.div>
    </div>
  </section>
);

const SupportedPlatforms = () => (
  <section className="py-16">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <h2 className="text-center text-lg font-semibold text-slate-400 mb-8">We provide support for issues related to all major exchanges and wallets</h2>
      <div className="flex flex-wrap justify-center items-center gap-x-8 gap-y-4 opacity-60">
        <img  alt="Binance logo" src="https://images.unsplash.com/photo-1614787296891-d1b2b1aced36" />
        <img  alt="Coinbase logo" src="https://images.unsplash.com/photo-1620980405967-b666535003cd" />
        <img  alt="Kraken logo" src="https://images.unsplash.com/photo-1585065799297-ce07d1855c01" />
        <img  alt="MetaMask logo" src="https://images.unsplash.com/photo-1683925234166-a9f25b5c4ca9" />
        <img  alt="Trust Wallet logo" src="https://images.unsplash.com/photo-1643101450344-f1f3dcde2411" />
        <img  alt="Ledger logo" src="https://images.unsplash.com/photo-1652020974081-0302bf66fe85" />
      </div>
    </div>
  </section>
);

const HowItWorksSection = () => (
  <section className="py-20 bg-slate-800/30">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
        <motion.div variants={itemVariants} className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">Get Help in 3 Simple Steps</h2>
          <p className="mt-4 max-w-xl mx-auto text-slate-300">Our process is designed to be straightforward and effective.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <motion.div variants={itemVariants} className="flex flex-col items-center">
            <div className="flex items-center justify-center w-16 h-16 bg-slate-800 border-2 border-violet-500 rounded-full text-2xl font-bold text-violet-400 mb-4">1</div>
            <h3 className="text-xl font-semibold text-white mb-2">Contact Us</h3>
            <p className="text-slate-400">Reach out via phone or our contact form with details of your issue.</p>
          </motion.div>
          <motion.div variants={itemVariants} className="flex flex-col items-center">
            <div className="flex items-center justify-center w-16 h-16 bg-slate-800 border-2 border-violet-500 rounded-full text-2xl font-bold text-violet-400 mb-4">2</div>
            <h3 className="text-xl font-semibold text-white mb-2">Free Consultation</h3>
            <p className="text-slate-400">Our experts will diagnose the problem and outline a solution plan.</p>
          </motion.div>
          <motion.div variants={itemVariants} className="flex flex-col items-center">
            <div className="flex items-center justify-center w-16 h-16 bg-slate-800 border-2 border-violet-500 rounded-full text-2xl font-bold text-violet-400 mb-4">3</div>
            <h3 className="text-xl font-semibold text-white mb-2">Problem Resolved</h3>
            <p className="text-slate-400">We guide you through the steps to resolve your issue securely.</p>
          </motion.div>
        </div>
      </motion.div>
    </div>
  </section>
);

const services = [
  { icon: ShieldCheck, title: 'Wallet Recovery', description: 'Assistance with recovering access to lost or inaccessible crypto wallets.' },
  { icon: LifeBuoy, title: 'Transaction Issues', description: 'Troubleshooting for pending, failed, or unconfirmed transactions.' },
  { icon: MessageSquare, title: 'Exchange Support', description: 'Help with account access, trading issues, and deposit/withdrawal problems.' },
];

const ServicesPreview = () => (
  <section className="py-20">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
        <motion.div variants={itemVariants} className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">Our Core Services</h2>
          <p className="mt-4 max-w-xl mx-auto text-slate-300">We offer a range of specialized services to resolve your crypto-related problems efficiently.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div key={index} variants={itemVariants} className="bg-slate-800 p-6 rounded-lg border border-slate-700 text-center">
              <div className="inline-block p-4 bg-violet-600/20 text-violet-400 rounded-full mb-4">
                <service.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
              <p className="text-slate-400">{service.description}</p>
            </motion.div>
          ))}
        </div>
        <motion.div variants={itemVariants} className="text-center mt-12">
          <Button asChild size="lg" variant="outline" className="border-violet-500 text-violet-400 hover:bg-violet-500/10 hover:text-violet-300 font-bold">
            <Link to="/services">View All Services</Link>
          </Button>
        </motion.div>
      </motion.div>
    </div>
  </section>
);

const DisclaimerSection = () => (
  <section className="py-16 bg-slate-800/30">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <h2 className="text-2xl font-bold text-amber-400 mb-4">Important Disclaimer</h2>
      <p className="max-w-3xl mx-auto text-slate-300">
        CryptoSupport Pro is an independent third-party service provider. We are not affiliated, associated, authorized, endorsed by, or in any way officially connected with any cryptocurrency exchange, wallet provider, or other entity. All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of them does not imply any affiliation with or endorsement by them.
      </p>
    </div>
  </section>
);

export default HomePage;