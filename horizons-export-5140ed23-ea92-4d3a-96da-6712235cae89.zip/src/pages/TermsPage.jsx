import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const TermsPage = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | CryptoSupport Pro</title>
        <meta name="description" content="Read the Terms of Service for CryptoSupport Pro, an independent third-party crypto support provider." />
      </Helmet>
      <div className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white">Terms of Service</h1>
            <p className="mt-2 text-slate-400">Last Updated: {new Date().toLocaleDateString()}</p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="mt-12 prose prose-invert prose-lg max-w-none text-slate-300 prose-headings:text-white prose-a:text-violet-400 hover:prose-a:text-violet-300"
          >
            <h2>1. Introduction</h2>
            <p>
              Welcome to CryptoSupport Pro. These Terms of Service ("Terms") govern your use of our website and the services we provide. By accessing our website or using our services, you agree to be bound by these Terms.
            </p>
            
            <h2>2. Disclaimer of Affiliation</h2>
            <p>
              CryptoSupport Pro is an independent third-party service provider. We are not affiliated, associated, authorized, endorsed by, or in any way officially connected with any cryptocurrency, exchange, or wallet platform. All brand names, logos, and trademarks are the property of their respective owners.
            </p>

            <h2>3. Services</h2>
            <p>
              We provide technical support and consultation services related to cryptocurrency issues. We will never ask for your private keys, seed phrases, or passwords. You are solely responsible for the security of your assets. Our guidance is based on information you provide and general best practices.
            </p>

            <h2>4. Limitation of Liability</h2>
            <p>
              Our services are provided on an "as is" and "as available" basis. We do not guarantee any specific outcome. In no event shall CryptoSupport Pro, nor its directors, employees, or partners, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the service.
            </p>

            <h2>5. User Responsibilities</h2>
            <p>
              You agree to provide accurate and complete information when requesting our services. You are responsible for implementing the solutions we suggest and for the security of your own accounts and wallets.
            </p>
            
            <h2>6. Changes to Terms</h2>
            <p>
              We reserve the right to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms on this page.
            </p>

            <h2>7. Contact Us</h2>
            <p>
              If you have any questions about these Terms, please contact us through our contact page.
            </p>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default TermsPage;