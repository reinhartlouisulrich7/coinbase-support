import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Users, Target, Eye } from 'lucide-react';

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 100,
    },
  },
};

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About Us | CryptoSupport Pro</title>
        <meta name="description" content="Learn about CryptoSupport Pro, our mission, and our team of independent experts dedicated to providing top-tier support for cryptocurrency users." />
      </Helmet>
      <div className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={{ visible: { transition: { staggerChildren: 0.2 } } }}
            className="text-center"
          >
            <motion.h1 variants={itemVariants} className="text-4xl sm:text-5xl font-extrabold text-white">About CryptoSupport Pro</motion.h1>
            <motion.p variants={itemVariants} className="mt-4 max-w-2xl mx-auto text-lg text-slate-300">
              Your trusted independent partner in navigating the complexities of the crypto world.
            </motion.p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-16 max-w-4xl mx-auto bg-slate-800/50 p-8 rounded-lg border border-slate-700"
          >
            <p className="text-slate-300 text-lg leading-relaxed">
              Founded by a group of blockchain enthusiasts and IT security professionals, CryptoSupport Pro was born out of a clear need for reliable, independent support in the cryptocurrency space. We saw countless users struggling with technical issues, frustrated by the lack of accessible and timely help from official channels. Our goal is to bridge that gap.
            </p>
            <p className="mt-4 text-slate-300 text-lg leading-relaxed">
              We are a third-party service provider, meaning we maintain complete independence from any exchange or wallet platform. This autonomy allows us to offer unbiased, user-centric advice and solutions tailored to your specific needs. Our team is committed to empowering you with the knowledge and support required to manage your digital assets safely and confidently.
            </p>
          </motion.div>

          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <motion.div variants={itemVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
              <div className="inline-block p-4 bg-violet-600/20 text-violet-400 rounded-full mb-4">
                <Target className="w-10 h-10" />
              </div>
              <h2 className="text-2xl font-bold text-white">Our Mission</h2>
              <p className="mt-2 text-slate-400">
                To provide accessible, expert-level technical support for cryptocurrency users, ensuring everyone can participate in the digital economy safely and securely.
              </p>
            </motion.div>
            <motion.div variants={itemVariants} initial="hidden" whileInView="visible" viewport={{ once: true, delay: 0.2 }}>
              <div className="inline-block p-4 bg-violet-600/20 text-violet-400 rounded-full mb-4">
                <Eye className="w-10 h-10" />
              </div>
              <h2 className="text-2xl font-bold text-white">Our Vision</h2>
              <p className="mt-2 text-slate-400">
                To be the most trusted and recognized independent support provider in the crypto industry, known for our integrity, expertise, and unwavering commitment to user security.
              </p>
            </motion.div>
            <motion.div variants={itemVariants} initial="hidden" whileInView="visible" viewport={{ once: true, delay: 0.4 }}>
              <div className="inline-block p-4 bg-violet-600/20 text-violet-400 rounded-full mb-4">
                <Users className="w-10 h-10" />
              </div>
              <h2 className="text-2xl font-bold text-white">Our Team</h2>
              <p className="mt-2 text-slate-400">
                Our team consists of seasoned IT professionals, cybersecurity experts, and blockchain developers with years of experience in the digital asset space.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AboutPage;