import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, ShieldCheck, LifeBuoy, MessageSquare, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { toast } from '@/components/ui/use-toast';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 100,
    },
  },
};

const LandingPage = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: 'Form Submitted!',
      description: 'Thank you for reaching out. We will get back to you shortly.',
      className: 'bg-green-500 text-white border-green-600',
    });
  };

  return (
    <div className="bg-slate-900 text-slate-50 overflow-x-hidden">
      <Header />
      <HeroSection />
      <ServicesSection />
      <SupportedPlatforms />
      <HowItWorksSection />
      <ContactSection handleSubmit={handleSubmit} />
      <FAQSection />
      <Footer />
    </div>
  );
};

const Header = () => (
  <motion.header
    initial={{ y: -100 }}
    animate={{ y: 0 }}
    transition={{ duration: 0.5 }}
    className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700/50"
  >
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center py-4">
      <div className="flex items-center space-x-2">
        <LifeBuoy className="w-8 h-8 text-violet-400" />
        <span className="text-xl font-bold text-white">CryptoSupport Pro</span>
      </div>
      <div className="flex items-center space-x-4">
        <a href="tel:+1-800-555-0199" className="hidden sm:flex items-center space-x-2 text-violet-300 hover:text-violet-200 transition-colors">
          <Phone className="w-4 h-4" />
          <span>+1 (800) 555-0199</span>
        </a>
        <Button asChild className="bg-violet-600 hover:bg-violet-700 text-white font-semibold">
          <a href="#contact">Get Help Now</a>
        </Button>
      </div>
    </div>
  </motion.header>
);

const HeroSection = () => (
  <section className="relative py-20 sm:py-28 text-center overflow-hidden">
    <div className="glow-effect"></div>
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
      <motion.div variants={containerVariants} initial="hidden" animate="visible">
        <motion.h1 variants={itemVariants} className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight">
          Expert Support for Your Crypto & Exchange Needs
        </motion.h1>
        <motion.p variants={itemVariants} className="mt-6 max-w-2xl mx-auto text-lg text-slate-300">
          Facing issues with your wallet, transactions, or exchange account? Our independent team of specialists is here to provide fast, reliable third-party support.
        </motion.p>
        <motion.div variants={itemVariants} className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-4">
          <Button asChild size="lg" className="w-full sm:w-auto bg-violet-600 hover:bg-violet-700 text-white font-bold shadow-lg shadow-violet-500/20">
            <a href="tel:+1-800-555-0199">
              <Phone className="mr-2 h-5 w-5" /> Call for Immediate Help
            </a>
          </Button>
          <Button asChild size="lg" variant="outline" className="w-full sm:w-auto border-violet-500 text-violet-400 hover:bg-violet-500/10 hover:text-violet-300 font-bold">
            <a href="#contact">
              <MessageSquare className="mr-2 h-5 w-5" /> Request a Callback
            </a>
          </Button>
        </motion.div>
        <motion.p variants={itemVariants} className="mt-4 text-sm text-slate-400">
          Disclaimer: We are an independent third-party service provider and are not affiliated with any specific cryptocurrency or exchange.
        </motion.p>
      </motion.div>
    </div>
  </section>
);

const services = [
  { icon: ShieldCheck, title: 'Wallet Recovery', description: 'Assistance with recovering access to lost or inaccessible crypto wallets.' },
  { icon: LifeBuoy, title: 'Transaction Issues', description: 'Troubleshooting for pending, failed, or unconfirmed transactions.' },
  { icon: MessageSquare, title: 'Exchange Support', description: 'Help with account access, trading issues, and deposit/withdrawal problems.' },
  { icon: ShieldCheck, title: 'Security Audits', description: 'Personal security checks to protect your digital assets from threats.' },
];

const ServicesSection = () => (
  <section className="py-20 bg-slate-800/30">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
        <motion.div variants={itemVariants} className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">Our Support Services</h2>
          <p className="mt-4 max-w-xl mx-auto text-slate-300">We offer a range of specialized services to resolve your crypto-related problems efficiently.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div key={index} variants={itemVariants} className="bg-slate-800 p-6 rounded-lg border border-slate-700 text-center hover:border-violet-500 hover:scale-105 transition-all duration-300">
              <div className="inline-block p-4 bg-violet-600/20 text-violet-400 rounded-full mb-4">
                <service.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
              <p className="text-slate-400">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  </section>
);

const SupportedPlatforms = () => (
  <section className="py-16">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <h3 className="text-center text-lg font-semibold text-slate-400 mb-8">We provide support for issues related to all major exchanges and wallets</h3>
      <div className="flex flex-wrap justify-center items-center gap-x-8 gap-y-4 opacity-60">
        <img  alt="Binance logo" src="https://images.unsplash.com/photo-1614787296891-d1b2b1aced36" />
        <img  alt="Coinbase logo" src="https://images.unsplash.com/photo-1579623261984-41f9a81d4044" />
        <img  alt="Kraken logo" src="https://images.unsplash.com/photo-1613140506142-277c6241b858" />
        <img  alt="MetaMask logo" src="https://images.unsplash.com/photo-1639322537163-dd9e9a344a97" />
        <img  alt="Trust Wallet logo" src="https://images.unsplash.com/photo-1614787296891-d1b2b1aced36" />
        <img  alt="Ledger logo" src="https://images.unsplash.com/photo-1652020974081-0302bf66fe85" />
      </div>
    </div>
  </section>
);

const HowItWorksSection = () => (
  <section className="py-20 bg-slate-800/30">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
        <motion.div variants={itemVariants} className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">Get Help in 3 Simple Steps</h2>
          <p className="mt-4 max-w-xl mx-auto text-slate-300">Our process is designed to be straightforward and effective.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <motion.div variants={itemVariants} className="flex flex-col items-center">
            <div className="flex items-center justify-center w-16 h-16 bg-slate-800 border-2 border-violet-500 rounded-full text-2xl font-bold text-violet-400 mb-4">1</div>
            <h3 className="text-xl font-semibold text-white mb-2">Contact Us</h3>
            <p className="text-slate-400">Reach out via phone or our contact form with details of your issue.</p>
          </motion.div>
          <motion.div variants={itemVariants} className="flex flex-col items-center">
            <div className="flex items-center justify-center w-16 h-16 bg-slate-800 border-2 border-violet-500 rounded-full text-2xl font-bold text-violet-400 mb-4">2</div>
            <h3 className="text-xl font-semibold text-white mb-2">Free Consultation</h3>
            <p className="text-slate-400">Our experts will diagnose the problem and outline a solution plan.</p>
          </motion.div>
          <motion.div variants={itemVariants} className="flex flex-col items-center">
            <div className="flex items-center justify-center w-16 h-16 bg-slate-800 border-2 border-violet-500 rounded-full text-2xl font-bold text-violet-400 mb-4">3</div>
            <h3 className="text-xl font-semibold text-white mb-2">Problem Resolved</h3>
            <p className="text-slate-400">We guide you through the steps to resolve your issue securely.</p>
          </motion.div>
        </div>
      </motion.div>
    </div>
  </section>
);

const ContactSection = ({ handleSubmit }) => (
  <section id="contact" className="py-20">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">Request a Callback</h2>
          <p className="mt-4 text-slate-300">Fill out the form below, and one of our support specialists will contact you shortly. All information is kept confidential.</p>
          <div className="mt-8 space-y-4">
            <div className="flex items-start space-x-4">
              <CheckCircle className="w-6 h-6 text-violet-400 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-white">Secure Communication</h3>
                <p className="text-slate-400">Your data is protected and never shared.</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <CheckCircle className="w-6 h-6 text-violet-400 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-white">Expert Analysis</h3>
                <p className="text-slate-400">We provide a clear assessment of your issue.</p>
              </div>
            </div>
          </div>
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}>
          <form onSubmit={handleSubmit} className="bg-slate-800 p-8 rounded-lg border border-slate-700 space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-slate-300">Full Name</Label>
              <Input id="name" type="text" placeholder="John Doe" required className="bg-slate-900 border-slate-600 text-white focus:ring-violet-500" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-slate-300">Email Address</Label>
              <Input id="email" type="email" placeholder="you@example.com" required className="bg-slate-900 border-slate-600 text-white focus:ring-violet-500" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="issue" className="text-slate-300">Describe Your Issue</Label>
              <textarea id="issue" placeholder="Please provide a brief description of the problem..." required className="w-full min-h-[100px] bg-slate-900 border border-slate-600 rounded-md p-2 text-white focus:ring-violet-500 focus:outline-none"></textarea>
            </div>
            <Button type="submit" className="w-full bg-violet-600 hover:bg-violet-700 text-white font-semibold text-lg py-3">Submit Request</Button>
          </form>
        </motion.div>
      </div>
    </div>
  </section>
);

const faqs = [
  { q: "Are you an official support for exchanges like Binance or Coinbase?", a: "No, we are an independent third-party support service. We are not affiliated, associated, authorized, endorsed by, or in any way officially connected with any cryptocurrency exchange or wallet provider." },
  { q: "Is my information safe with you?", a: "Absolutely. We prioritize your privacy and security. All communication is encrypted, and we have strict data protection policies in place. We will never ask for your private keys or seed phrases." },
  { q: "What kind of issues can you help with?", a: "We can assist with a wide range of issues, including wallet access problems, transaction troubleshooting, account security, and general guidance on using crypto platforms safely." },
  { q: "What are your fees?", a: "We offer a free initial consultation to diagnose your issue. Afterward, we provide a transparent, upfront quote based on the complexity of the work required. There are no hidden fees." },
];

const FAQSection = () => (
  <section className="py-20 bg-slate-800/30">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
      <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
        <motion.div variants={itemVariants} className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">Frequently Asked Questions</h2>
        </motion.div>
        <motion.div variants={itemVariants}>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-lg font-semibold hover:text-violet-300">{faq.q}</AccordionTrigger>
                <AccordionContent className="text-slate-300 text-base">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </motion.div>
    </div>
  </section>
);

const Footer = () => (
  <footer className="bg-slate-900 border-t border-slate-700/50">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center text-slate-400">
        <p className="font-bold text-lg text-slate-200 mb-2">CryptoSupport Pro</p>
        <p className="text-sm">Independent Third-Party Support Services</p>
        <div className="flex justify-center space-x-6 my-4">
          <a href="#" className="hover:text-violet-400 transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-violet-400 transition-colors">Terms of Service</a>
        </div>
        <p className="text-xs">&copy; {new Date().getFullYear()} CryptoSupport Pro. All Rights Reserved.</p>
        <p className="text-xs mt-2 max-w-2xl mx-auto">
          Disclaimer: CryptoSupport Pro is an independent service provider. We are not affiliated with any cryptocurrency, exchange, or wallet platform. All brand names, logos, and trademarks are the property of their respective owners and are used for identification purposes only.
        </p>
      </div>
    </div>
  </footer>
);

export default LandingPage;