import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const MarketOverview = ({ cryptos, setSelectedCrypto, formatPrice, formatMarketCap }) => {
  return (
    <motion.div 
      className="bg-card rounded-lg"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <div className="p-4 border-b border-gray-700/50 flex items-center justify-between">
        <h3 className="text-lg font-bold flex items-center text-white">
          <BarChart3 className="w-5 h-5 mr-3 text-yellow-400" />
          Market Overview
        </h3>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => toast({
            title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
            className: 'bg-gray-800 text-white border-yellow-500',
          })}
        >
          View All
        </Button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-gray-400 uppercase bg-gray-800/30">
            <tr>
              <th scope="col" className="px-6 py-3">#</th>
              <th scope="col" className="px-6 py-3">Name</th>
              <th scope="col" className="px-6 py-3 text-right">Price</th>
              <th scope="col" className="px-6 py-3 text-right">24h %</th>
              <th scope="col" className="px-6 py-3 text-right">Market Cap</th>
              <th scope="col" className="px-6 py-3 text-right">Volume (24h)</th>
            </tr>
          </thead>
          <tbody>
            {cryptos.map((crypto, index) => (
              <motion.tr
                key={crypto.id}
                className="border-b border-gray-700/50 hover:bg-gray-800/50 cursor-pointer"
                onClick={() => setSelectedCrypto(crypto.id)}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <td className="px-6 py-4 text-gray-400">{index + 1}</td>
                <th scope="row" className="px-6 py-4 font-medium text-white whitespace-nowrap">
                  <div className="flex items-center space-x-3">
                    <div className="w-7 h-7 bg-gray-700 rounded-full flex items-center justify-center text-sm font-bold text-yellow-400">
                      {crypto.icon}
                    </div>
                    <div>
                      <span>{crypto.name}</span>
                      <span className="text-gray-400 ml-2">{crypto.symbol}</span>
                    </div>
                  </div>
                </th>
                <td className="px-6 py-4 text-right font-medium">{formatPrice(crypto.price)}</td>
                <td className={`px-6 py-4 text-right font-medium ${crypto.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  <div className="flex items-center justify-end space-x-1">
                    {crypto.change24h >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                    <span>{Math.abs(crypto.change24h).toFixed(2)}%</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-gray-300">{formatMarketCap(crypto.marketCap)}</td>
                <td className="px-6 py-4 text-right text-gray-300">{formatMarketCap(crypto.volume)}</td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
};

export default MarketOverview;