import React from 'react';
import { motion } from 'framer-motion';
import { Eye } from 'lucide-react';

const Watchlist = ({ watchlist, formatPrice }) => {
  return (
    <motion.div 
      className="bg-card rounded-lg p-4"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <h3 className="text-md font-bold mb-4 flex items-center text-white">
        <Eye className="w-5 h-5 mr-2 text-yellow-400" />
        Watchlist
      </h3>
      
      {watchlist.length === 0 ? (
        <div className="text-center py-6">
          <img  alt="Empty watchlist illustration" className="w-20 h-20 mx-auto mb-3 opacity-30" src="https://images.unsplash.com/photo-1618243329711-359c196ffb38" />
          <p className="text-sm text-gray-400">Your watchlist is empty.</p>
          <p className="text-xs text-gray-500">Click the star to add assets.</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {watchlist.map((item) => (
            <div key={item.id} className="bg-gray-900/50 rounded-md p-3 text-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-yellow-400">{item.icon}</span>
                  <div>
                    <p className="font-semibold text-white">{item.symbol}</p>
                    <p className="text-xs text-gray-400">{item.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-white">{formatPrice(item.price)}</p>
                  <p className={`text-xs font-medium ${item.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {item.change24h >= 0 ? '+' : ''}{item.change24h.toFixed(2)}%
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
};

export default Watchlist;