import React from 'react';
import { motion } from 'framer-motion';
import { DollarSign } from 'lucide-react';

const StatItem = ({ label, value }) => (
  <div className="flex justify-between items-center text-sm">
    <span className="text-gray-400">{label}</span>
    <span className="font-bold text-white">{value}</span>
  </div>
);

const MarketStats = () => {
  return (
    <motion.div 
      className="bg-card rounded-lg p-4"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <h3 className="text-md font-bold mb-4 flex items-center text-white">
        <DollarSign className="w-5 h-5 mr-2 text-blue-400" />
        Market Stats
      </h3>
      
      <div className="space-y-3">
        <StatItem label="Total Market Cap" value="$2.1T" />
        <StatItem label="24h Volume" value="$89.2B" />
        <StatItem label="BTC Dominance" value="52.3%" />
        <StatItem label="Active Cryptos" value="13,456" />
      </div>
    </motion.div>
  );
};

export default MarketStats;