import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ArrowDownRight, Plus, Minus, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const FeaturedCrypto = ({ crypto, formatPrice, formatMarketCap, addToPortfolio, removeFromPortfolio, addToWatchlist }) => {
  if (!crypto) return null;

  const isPositiveChange = (crypto.change24h || 0) >= 0;

  return (
    <motion.div 
      className="bg-card rounded-lg p-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4">
        <div className="flex items-center space-x-4 mb-4 sm:mb-0">
          <div className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center text-2xl font-bold text-yellow-400">
            {crypto.icon}
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">{crypto.name}</h2>
            <p className="text-gray-400 text-md">{crypto.symbol}</p>
          </div>
        </div>
        <div className="text-left sm:text-right">
          <div className="text-3xl font-bold text-white mb-1">
            {formatPrice(crypto.price || 0)}
          </div>
          <div className={`flex items-center justify-start sm:justify-end space-x-1 ${isPositiveChange ? 'text-green-400' : 'text-red-400'}`}>
            {isPositiveChange ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
            <span className="text-md font-semibold">
              {Math.abs(crypto.change24h || 0).toFixed(2)}%
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-gray-900/50 rounded-md p-3">
          <p className="text-xs text-gray-400 mb-1">Market Cap</p>
          <p className="text-sm font-bold text-white">{formatMarketCap(crypto.marketCap || 0)}</p>
        </div>
        <div className="bg-gray-900/50 rounded-md p-3">
          <p className="text-xs text-gray-400 mb-1">24h Volume</p>
          <p className="text-sm font-bold text-white">{formatMarketCap(crypto.volume || 0)}</p>
        </div>
        <div className="bg-gray-900/50 rounded-md p-3">
          <p className="text-xs text-gray-400 mb-1">Circulating Supply</p>
          <p className="text-sm font-bold text-white">{formatMarketCap(crypto.marketCap / crypto.price)}</p>
        </div>
      </div>

      <div className="flex space-x-2">
        <Button 
          className="flex-1 bg-green-500 hover:bg-green-600 text-white font-semibold"
          onClick={() => addToPortfolio(crypto)}
        >
          <Plus className="w-4 h-4 mr-2" />
          Buy
        </Button>
        <Button 
          variant="outline" 
          className="flex-1 border-red-500/50 text-red-400 hover:bg-red-500/20 hover:text-red-300 font-semibold"
          onClick={() => removeFromPortfolio(crypto.id)}
        >
          <Minus className="w-4 h-4 mr-2" />
          Sell
        </Button>
        <Button 
          variant="outline" 
          className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/20 hover:text-yellow-300"
          onClick={() => addToWatchlist(crypto)}
        >
          <Star className="w-4 h-4" />
        </Button>
      </div>
    </motion.div>
  );
};

export default FeaturedCrypto;