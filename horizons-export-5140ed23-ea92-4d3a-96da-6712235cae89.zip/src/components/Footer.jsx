import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="bg-slate-900 border-t border-slate-700/50">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center text-slate-400">
        <p className="font-bold text-lg text-slate-200 mb-2">CryptoSupport Pro</p>
        <p className="text-sm">Independent Third-Party Support Services</p>
        <div className="flex justify-center space-x-6 my-4">
          <Link to="/privacy-policy" className="hover:text-violet-400 transition-colors">Privacy Policy</Link>
          <Link to="/terms-of-service" className="hover:text-violet-400 transition-colors">Terms of Service</Link>
          <Link to="/contact" className="hover:text-violet-400 transition-colors">Contact Us</Link>
        </div>
        <p className="text-xs">&copy; {new Date().getFullYear()} CryptoSupport Pro. All Rights Reserved.</p>
        <p className="text-xs mt-2 max-w-2xl mx-auto">
          Disclaimer: CryptoSupport Pro is an independent service provider. We are not affiliated with any cryptocurrency, exchange, or wallet platform. All brand names, logos, and trademarks are the property of their respective owners and are used for identification purposes only.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;