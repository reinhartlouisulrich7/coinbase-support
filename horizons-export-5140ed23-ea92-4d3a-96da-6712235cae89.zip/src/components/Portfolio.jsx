import React from 'react';
import { motion } from 'framer-motion';
import { Wallet } from 'lucide-react';

const Portfolio = ({ portfolio, totalPortfolioValue, formatPrice }) => {
  return (
    <motion.div 
      className="bg-card rounded-lg p-4"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h3 className="text-md font-bold mb-4 flex items-center text-white">
        <Wallet className="w-5 h-5 mr-2 text-green-400" />
        My Portfolio
      </h3>
      
      {portfolio.length === 0 ? (
        <div className="text-center py-6">
          <img  alt="Empty portfolio illustration" className="w-20 h-20 mx-auto mb-3 opacity-30" src="https://images.unsplash.com/photo-1698376621066-8bdd073dcf4a" />
          <p className="text-sm text-gray-400">Your portfolio is empty.</p>
          <p className="text-xs text-gray-500">Buy assets to see them here.</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-60 overflow-y-auto">
          {portfolio.map((item) => (
            <div key={item.id} className="bg-gray-900/50 rounded-md p-3 text-sm">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-yellow-400">{item.icon}</span>
                  <span className="font-semibold text-white">{item.symbol}</span>
                </div>
                <span className="font-medium text-white">{item.amount.toFixed(4)}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-400">Value:</span>
                <span className="font-medium text-green-400">
                  {formatPrice(item.price * item.amount)}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="border-t border-gray-700/50 mt-4 pt-3">
        <div className="flex justify-between items-center">
          <span className="text-sm font-semibold text-gray-300">Total Value:</span>
          <span className="text-lg font-bold text-green-400">
            {formatPrice(totalPortfolioValue)}
          </span>
        </div>
      </div>
    </motion.div>
  );
};

export default Portfolio;