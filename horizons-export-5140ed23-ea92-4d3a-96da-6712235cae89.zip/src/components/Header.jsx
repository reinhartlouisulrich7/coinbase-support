import React from 'react';
import { motion } from 'framer-motion';
import { LifeBuoy, Phone } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const CustomNavLink = ({ to, children }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `text-slate-300 hover:text-violet-300 transition-colors duration-200 font-medium ${
        isActive ? 'text-violet-400' : ''
      }`
    }
  >
    {children}
  </NavLink>
);

const Header = () => (
  <motion.header
    initial={{ y: -100 }}
    animate={{ y: 0 }}
    transition={{ duration: 0.5 }}
    className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700/50"
  >
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center py-4">
      <NavLink to="/" className="flex items-center space-x-2">
        <LifeBuoy className="w-8 h-8 text-violet-400" />
        <span className="text-xl font-bold text-white">CryptoSupport Pro</span>
      </NavLink>
      <nav className="hidden md:flex items-center space-x-6">
        <CustomNavLink to="/">Home</CustomNavLink>
        <CustomNavLink to="/about">About Us</CustomNavLink>
        <CustomNavLink to="/services">Services</CustomNavLink>
        <CustomNavLink to="/contact">Contact Us</CustomNavLink>
      </nav>
      <div className="flex items-center space-x-4">
        <a href="tel:+1-800-555-0199" className="hidden sm:flex items-center space-x-2 text-violet-300 hover:text-violet-200 transition-colors">
          <Phone className="w-4 h-4" />
          <span>+1 (800) 555-0199</span>
        </a>
        <Button asChild className="bg-violet-600 hover:bg-violet-700 text-white font-semibold">
          <NavLink to="/contact">Get Help Now</NavLink>
        </Button>
      </div>
    </div>
  </motion.header>
);

export default Header;