export const cryptoData = [
  {
    id: 'bitcoin',
    name: 'Bitcoin',
    symbol: 'BTC',
    price: 43250.67,
    change24h: 2.45,
    marketCap: 847000000000,
    volume: 28500000000,
    icon: '₿'
  },
  {
    id: 'ethereum',
    name: 'Ethereum',
    symbol: 'ETH',
    price: 2650.89,
    change24h: -1.23,
    marketCap: 318000000000,
    volume: 15200000000,
    icon: 'Ξ'
  },
  {
    id: 'cardano',
    name: 'Cardano',
    symbol: 'ADA',
    price: 0.485,
    change24h: 5.67,
    marketCap: 17200000000,
    volume: 890000000,
    icon: '₳'
  },
  {
    id: 'solana',
    name: 'Solana',
    symbol: 'SOL',
    price: 98.45,
    change24h: -3.21,
    marketCap: 42800000000,
    volume: 2100000000,
    icon: '◎'
  },
  {
    id: 'polkadot',
    name: 'Polkadot',
    symbol: 'DOT',
    price: 7.23,
    change24h: 1.89,
    marketCap: 9200000000,
    volume: 450000000,
    icon: '●'
  },
  {
    id: 'chainlink',
    name: 'Chainlink',
    symbol: 'LINK',
    price: 14.67,
    change24h: 4.12,
    marketCap: 8100000000,
    volume: 680000000,
    icon: '⬢'
  },
  {
    id: 'dogecoin',
    name: 'Dogecoin',
    symbol: 'DOGE',
    price: 0.085,
    change24h: 0.55,
    marketCap: 12100000000,
    volume: 540000000,
    icon: 'Ð'
  },
  {
    id: 'ripple',
    name: 'XRP',
    symbol: 'XRP',
    price: 0.52,
    change24h: -0.89,
    marketCap: 28000000000,
    volume: 1100000000,
    icon: '✕'
  }
];